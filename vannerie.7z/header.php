<!-- ============ HEADER SECTION ============== -->
<tr id="header" >
<td></td>
<td colspan="" >
<a href="index.php" ><img src="images/logo_vannerie.gif" title="Home"/></a></td>
<td></td>
</tr>

<!-- ============ NAVIGATION BAR SECTION ============== -->
<tr id="navbar" align=center height=30 >
<td colspan="3" valign="middle" style="margin:0;padding:0;">
<ul>
<li><a class="<? echo $current['index'] ?>" href="index.php"      >accueil</a> |</li>
<li><a class="<? echo $current['activites'] ?>" href="activites.php"  >activités</a> |</li>
<li><a class="<? echo $current['sejours'] ?>" href="sejours.php"    >séjours</a> |</li>
<li><a class="<? echo $current['minicamps'] ?>" href="minicamps.php"  >mini camps</a> |</li>
<li><a class="<? echo $current['groupes'] ?>" href="groupes.php"    >journée groupe</a> |</li>
<li><a class="<? echo $current['seminaires'] ?>" href="seminaires.php" >séminaires</a> |</li>
<li><a class="<? echo $current['locations'] ?>" href="locations.php"  >locations</a> |</li>
<li><a class="<? echo $current['tarifs'] ?>" href="tarifs.php"     >tarifs</a> |</li>
<li><a class="<? echo $current['photos'] ?>" href="photos.php"     >photos</a> |</li>
<li><a class="<? echo $current['contact'] ?>" href="contact.php"    >contact</a> |</li>
<li><a class="<? echo $current['agenda'] ?>" href="agenda.php"     >agenda</a></li></ul>
</td>

</tr>
<!--End Navigation-->

<!--End Header-->
<tr>
