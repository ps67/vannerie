
<td id="rightbar">

<!-- =========== Debut Section =========== -->
<h3> Activités:</h3>
<a href="tennis.php" >Tennis</a><BR>
<a href="minigolf.php" >Mini Golf</a><BR>
<a href="piscine.php" >Piscine</a><BR>
<a href="volley.php" >Beach-Volley</a><BR>
<a href="terrasse.php" >Terrasse</a><BR>
<a href="kayak.php" >Kayak</a><BR>
<a href="escalade.php" >Escalade</a><BR>
<a href="vtt.php" >VTT</a><BR>

<!-- =========== FIN Section =========== -->
</td> 