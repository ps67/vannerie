<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("terrasse");
?>

</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->
<p/>
<h1 style="background:#369 ; color: #fff;display:inline ;" >&nbsp; Terrasse et Buvette &nbsp;</h1>
<p/>
<p align="center"><img src="images/alcool.gif" width="100" height="137" /></p>
<table style="font-size:18pt">
    <tr>
        <td width="480">
Venez nombreux vous
d&eacute;salt&eacute;rer et vous ressourcer dans un cadre idyllique entre La Moselle
et la for&ecirc;t. Au bord de la piscine, une terrasse plein sud entre le
minigolf et le beach volley vous y attend pour un moment de d&eacute;tente en
famille ou entre amis.
       </td>
        <td width="480" align=center>
            <a href="#" class="swap" > <!-- ==== Images SWAP ==== -->
        </td>
    </tr>
</table>
<p/>
<p style="font-size:20pt;font-weight:bold;color:blue;"><em>La buvette du centre est ouverte &agrave; tous</p>

<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>
<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  