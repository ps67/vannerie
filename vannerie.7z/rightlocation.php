
<td id="rightbar">

<!-- =========== Debut Section =========== -->
<h3> Tarifs des locations:</h3>
<a href="#t1" >Carte Loisirs</a><BR>
<a href="#t2" >Mini Golf</a><BR>
<a href="#t3" >Tennis</a><BR>
<a href="#t4" >VTT</a><BR>
<a href="#t5" >Kayak</a><BR>
<a href="#t6" >Beach-Volley</a><BR>
<!-- =========== FIN Section =========== -->
</td> 