<?php
/* ============ HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("activites")
 ?>

 </head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->

<p>
<h1>&nbsp; ACTIVITÉS &nbsp; </h1>
</p><br>
<img src="images/activites.jpg">
<p/>



<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>
  
<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  