<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("kayak");
?>

</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->
<p/>
<h1 style="background:#369 ; color: #fff;display:inline ;" >&nbsp; Cano&euml;  Kayak &nbsp;</h1>
<p/>
<p align="center"><img src="images/kayak.gif" width="175" height="107" ></p>
<table style="font-size:18pt">
    <tr>
        <td width="480">
En solo ou en duo, une promenade en eau calme sur la Moselle entour&eacute;e de sites merveilleux.
<p/>
Vous pourrez &eacute;galement
partir &agrave; la journ&eacute;e en pr&eacute;voyant un arr&ecirc;t repas sur les berges de la Moselle.
       </td>
        <td width="480" align=center>
            <a href="#" class="swap" > <!-- ==== Images SWAP ==== -->
        </td>
    </tr>
</table>
<p/>
<p style="font-size:20pt;font-weight:bold;color:blue;"><em>Acc&egrave;s&nbsp;ouvert&nbsp;&agrave;&nbsp;tous</p>

<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>

<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  