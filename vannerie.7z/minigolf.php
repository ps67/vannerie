<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("minigolf");
?>

</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->
<p/>
<h1 style="background:#369 ; color: #fff;display:inline ;" >&nbsp; Minigolf &nbsp;</h1>
<p/>
<p align="center"><img src="images/golfeur.gif" width="175" height="107" ></p>
<table style="font-size:18pt">
    <tr>
        <td width="480">
Depuis quelques ann&eacute;es, le centre s'est enrichi d'un minigolf de grand standing.
<P/>Cette installation poss&egrave;de 18 trous aussi ludiques que techniques dans un merveilleux d&eacute;cor.
<P/>De plus, il est recouvet de schiste assurant une grande stabilit&eacute;.
       </td>
        <td width="480" align=center>
            <a href="#" class="swap" > <!-- ==== Images SWAP ==== -->
        </td>
    </tr>
</table>
<p/>
<p style="font-size:20pt;font-weight:bold;color:blue;"><em>Acc&egrave;s&nbsp;ouvert&nbsp;&agrave;&nbsp;tous</p>

<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>

<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  