<tr>
<!-- ============ LEFT COLUMN (MENU) ============== -->
<td id="leftbar">
<!-- ============ debut section ============== -->

<div style="width:195px">
<h2 style="font-size:14pt;background: #369;color: #fff;display:inline">&nbsp; Agenda &nbsp;</h2>
<p><u>Le 13 avril:</u> Activités gratuites pour tous</p>
<a href="contact.php" style="padding-top:5px" ><img src="images/info.jpg" /></a>
</div>

<div id="menu">
<img src="images/contact.jpg" />
</div>

<!-- ============ fin section ============== -->
</td>
