<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("vtt");
?>

</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
<?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->
<p/>
<h1 style="background:#369 ; color: #fff;display:inline ;" >&nbsp; VTT &nbsp;</h1>
<p/>
<p align="center"><img src="images/vtt.gif" width="100" height="97" ></p>
<table style="font-size:18pt">
    <tr>
        <td width="480">
Au d&eacute;part de la piste
cyclable des boucles de la Moselle et au creux de&nbsp;la for&ecirc;t de Haye, vous pourrez go&ucirc;ter aux
joies d'une ballade &agrave; v&eacute;lo tranquille ou sportive.<P/>Le centre met &agrave; votre
disposition d'excellents VTT adultes ou jeunes de tous &acirc;ges.
       </td>
        <td width="480" align=center>
            <a href="#" class="swap" > <!-- ==== Images SWAP ==== -->
        </td>
    </tr>
</table>
<p/>
<p style="font-size:20pt;font-weight:bold;color:blue;"><em>Acc&egrave;s&nbsp;ouvert&nbsp;&agrave;&nbsp;tous</p>

<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>

<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  