<!-- ============ FOOTER SECTION ============== -->
<tr align="center" height="20" id="footer" >
<td colspan=3>

<table width=100% style="color:#fff;">
<tr>
<td align=right width=17%>Visites&nbsp;</td>
<td align=left width=8%>
<span style="background:#fff;color:rgb(32,32,32)"><b><?php echo (isset($compte))? $compte : ""; ?></b></span></td>
<td align=center>
Centre de loisirs La Vannerie<BR>
54450 Sexey aux Forges
</td>
<td align=right width=10%>Mise à jour 30/03/2014</td>
</tr>
</table>

</td>
</tr>
<!-- ============ FIN SECTION ============== -->

</table>
</body>
</html>
