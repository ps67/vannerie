<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("photos")
?>
</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->

<H2>Un après-midi récréatif</H2>
<P>
<center>

<iframe style="width: 555px; height: 420px;" src="http://www.gmodules.com/gadgets/ifr?url=http://prac-gadget.googlecode.com/files/google-plus-slideshow.xml&amp;up_URL=https://plus.google.com/u/0/photos/108660016008972313194/albums/5986630127264579393&amp;up_PWH=535&amp;up_PHT=400&amp;up_DTime=3000&amp;up_TTime=800&amp;up_RND=Yes&amp;up_CLP=no&amp;up_NAB=Yes&amp;up_SCOL=%23d1dae3&amp;up_BCOL=%23d1dae3&amp;up_CCOL=%23d1dae3" allowtransparency="true" frameborder="0" scrolling="no"></iframe>

<P><BR>
<table width=600 style="text-align:center">
<tr>
<td width=200><a href="diapo1.php" title="diapo 1" ><img src="images/play1.png" border="1"/></a></td>
<td width=200><a href="diapo2.php" title="diapo 2" ><img src="images/play2.png" border="1"/></a></td>
<td width=200><a href="diapo3.php" title="diapo 3" ><img src="images/play3.png" border="1"/></a></td>
</tr><tr>
<td>Activités</td>
<td>Anniversaire</td>
<td>Après-midi récréatif</td>
</tr>
</table>


<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
<td id="rightbar">&nbsp;</td>
  
<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  