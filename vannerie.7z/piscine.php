<?php
/* ============== HEAD PAGE SECTION ============== */
include("headpage.php");
headpage("piscine");
?>

</head>
<body>

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">

<!-- ============ HEADER SECTION ============== -->
<?php include("header.php"); ?>

<!-- ============ LEFT SIDE SECTION ============== -->
  <?php include("sidebar.php"); ?>

  <!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
<td id="main" align=center>
<!-- ============ DEBUT SECTION ============== -->
<p/>
<h1 style="background:#369 ; color: #fff;display:inline ;" >&nbsp; Piscine &nbsp;</h1>
<p/>
<p align="center"><img src="images/donald7.gif" width="105" height="108" ></p>
<table style="font-size:18pt">
    <tr>
        <td width="480">
Vous pourrez profiter de la piscine pour vous y délasser après vos multiples activités
 et vous rafraîchir à la buvette.
       </td>
        <td width="480" align=center>
            <a href="#" class="swap" > <!-- ==== Images SWAP ==== -->
        </td>
    </tr>
</table>

<div style="text-align:left;font-size:18pt;font-weight:bold;padding-left:2cm;color:blue;">
<em>L'acc&egrave;s est r&eacute;serv&eacute;:</em>
<ul>
<li>Aux adh&eacute;rents tennis.</li>
<li>Aux stagiaires</li>
<li>Aux d&eacute;tenteurs de la carte loisirs</li>
<li>Aux groupes lors de journ&eacute;es d&eacute;tente</li>
</ul>
</div>
<p/>
	
<!-- ============ FIN SECTION ============== -->
</td>
<!-- ============ RIGHT COLUMN (MENU) ============== -->
  <?php include("rightbar.php"); ?>

<!-- ============ FOOTER SECTION ============== -->
  <?php include("footer.php"); ?>
  